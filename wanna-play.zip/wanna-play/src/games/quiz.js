import { h, wait, confetti, fill } from '../ui.js';
import { sfx } from '../audio.js';

// [round, question, correct answer, three wrong answers]
const Q = [
  ['Barbie', 'In what year did Barbie make her debut?', '1959', ['1949', '1965', '1971']],
  ['Barbie', "What is Barbie's full name?", 'Barbara Millicent Roberts', ['Barbara Ann Handler', 'Barbie Marie Carson', 'Barbara Jean Mattel']],
  ['Barbie', 'Who created Barbie?', 'Ruth Handler', ['Pleasant Rowland', 'Elliot Handler', 'Merle Robbins']],
  ['Barbie', "What is Barbie's fictional hometown?", 'Willows, Wisconsin', ['Malibu, California', 'Springfield, Ohio', 'Sunnyvale, Florida']],
  ['Barbie', 'In what year was Ken introduced?', '1961', ['1959', '1968', '1975']],
  ['Barbie', 'Who directed the 2023 Barbie movie?', 'Greta Gerwig', ['Sofia Coppola', 'Patty Jenkins', 'Olivia Wilde']],
  ['Hot Wheels Hot Takes', 'In what year did Hot Wheels launch?', '1968', ['1958', '1975', '1982']],
  ['Hot Wheels Hot Takes', 'How many cars were in the original Hot Wheels line-up?', '16', ['8', '24', '50']],
  ['Hot Wheels Hot Takes', 'What scale are standard Hot Wheels cars?', '1:64', ['1:18', '1:32', '1:100']],
  ['Hot Wheels Hot Takes', 'What colour is the classic Hot Wheels track?', 'Orange', ['Blue', 'Red', 'Yellow']],
  ['UNO Reverse', 'The answer is "108". What is the question?', 'How many cards are in a standard UNO deck?', ['How many countries sell UNO?', 'What year was UNO invented?', 'How many points wins a game of UNO?']],
  ['UNO Reverse', 'The answer is "a barber from Ohio". What is the question?', 'Who invented UNO?', ['Who founded Mattel?', 'Who designed Hot Wheels?', 'Who created Polly Pocket?']],
  ['UNO', 'In what year was UNO invented?', '1971', ['1961', '1981', '1991']],
  ['UNO', 'In what year did UNO join the Mattel family?', '1992', ['1972', '1985', '2001']],
  ['UNO', 'Which card makes the next player pick up four?', 'Wild Draw Four', ['Reverse', 'Skip', 'Draw Two']],
  ['Masters of the Universe', "What is He-Man's home planet?", 'Eternia', ['Etheria', 'Thundera', 'Cybertron']],
  ['Masters of the Universe', 'Who is He-Man when he is not holding the Power Sword?', 'Prince Adam', ['Prince Adora', 'Duncan', 'Prince Keldor']],
  ['Masters of the Universe', 'What is the name of the castle He-Man protects?', 'Castle Grayskull', ['Snake Mountain', 'Crystal Castle', 'Castle Eternos']],
  ['Masters of the Universe', 'Where does Skeletor live?', 'Snake Mountain', ['Castle Grayskull', 'The Fright Zone', 'Skull Fortress']],
  ['Masters of the Universe', "What is the name of He-Man's armoured tiger?", 'Battle Cat', ['Panthor', 'Swift Wind', 'Tigra']],
  ['Polly Pocket', 'Polly Pocket was first sold in which year?', '1989', ['1979', '1995', '2001']],
  ['Polly Pocket', 'The first Polly Pocket was made inside what kind of case?', 'A makeup compact', ['A matchbox', 'A lunch box', 'A locket']],
  ['Monster High', 'In what year did Monster High launch?', '2010', ['2004', '2014', '2018']],
  ['Monster High', "Draculaura is the daughter of which famous monster?", 'Dracula', ['The Mummy', 'The Werewolf', "Frankenstein's monster"]],
  ['Monster High', 'What kind of monster is Clawdeen Wolf?', 'A werewolf', ['A vampire', 'A zombie', 'A sea monster']],
  ['American Girl', 'Who founded American Girl?', 'Pleasant Rowland', ['Ruth Handler', 'Margaret Fisher', 'Molly McIntire']],
  ['American Girl', 'In what year was American Girl founded?', '1986', ['1976', '1992', '2000']],
  ['Fisher-Price', 'In what year was Fisher-Price founded?', '1930', ['1910', '1945', '1960']],
  ['Fisher-Price', 'Fisher-Price was founded in which US state?', 'New York', ['California', 'Ohio', 'Michigan']],
  ['MEGA', 'MEGA construction toys come from which Canadian city?', 'Montreal', ['Toronto', 'Vancouver', 'Calgary']],
  ['Mattel', 'In what year was Mattel founded?', '1945', ['1929', '1959', '1968']],
  ['Mattel', 'The name "Mattel" combines the names of which two founders?', 'Matt and Elliot', ['Matthew and Ellen', 'Matson and Telford', 'Mattie and Ella']],
  ['Mattel', 'Where is Mattel headquartered?', 'El Segundo, California', ['Burbank, California', 'Chicago, Illinois', 'Providence, Rhode Island']],
  ['Magic 8 Ball Predictions', 'How many possible answers does a Magic 8 Ball have?', '20', ['8', '12', '32']],
  ['Magic 8 Ball Predictions', 'What shape is the die floating inside a Magic 8 Ball?', 'A 20-sided icosahedron', ['A cube', 'A pyramid', 'A sphere']],
  ['Matchbox', 'Matchbox cars were first made in which country?', 'England', ['United States', 'Germany', 'Japan']],
  ['LA28', 'LA28 will be the how-many-th time Los Angeles hosts the Summer Games?', 'Third', ['First', 'Second', 'Fourth']],
];

const face = (mood, hair, skin) => `<svg viewBox="0 0 120 120"><circle cx="60" cy="66" r="44" fill="${skin}"/><path d="M16 60a44 44 0 0 1 88 0c-10-22-78-22-88 0z" fill="${hair}"/>
<circle cx="44" cy="62" r="6" fill="#1c1030"/><circle cx="76" cy="62" r="6" fill="#1c1030"/>
${mood === 'happy' ? '<path d="M38 80q22 26 44 0z" fill="#1c1030"/><path d="M30 44l14-8M90 44l-14-8" stroke="#1c1030" stroke-width="5" stroke-linecap="round"/>' : mood === 'sad' ? '<path d="M42 92q18-18 36 0" stroke="#1c1030" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M32 46l14 6M88 46l-14 6" stroke="#1c1030" stroke-width="5" stroke-linecap="round"/>' : '<path d="M44 86q16 8 32 0" stroke="#1c1030" stroke-width="6" fill="none" stroke-linecap="round"/>'}</svg>`;

export function start(app, exit) {
  const root = h('div', { class: 'screen dim' }); app.overlay.append(root, app.gameBar('Creator Studio'));
  const hosts = h('div', { class: 'hosts' });
  const mood = (m) => { hosts.innerHTML = `<div class="host">${face(m, '#FF1F9E', '#e9b68e')}</div><div class="host">${face(m, '#3146E4', '#8f5c3c')}</div>`; hosts.animate(m === 'happy' ? [{ transform: 'translateY(0)' }, { transform: 'translateY(-22px)' }, { transform: 'translateY(0)' }] : m === 'sad' ? [{ transform: 'rotate(0)' }, { transform: 'rotate(-4deg)' }, { transform: 'rotate(0)' }] : [], { duration: 400, iterations: m === 'happy' ? 2 : 1 }); };
  const card = h('div', { class: 'card', style: 'min-width:min(640px,90vw)' });
  root.append(hosts, card);

  function intro() {
    mood('ok');
    fill(card, h('h2', {}, 'Live from the Creator Studio'), h('p', {}, 'Eight questions on the worlds of Mattel. Get six right to win the ring. The hosts are watching.'), h('button', { class: 'btn', onclick: run }, 'Start the show'));
  }
  async function run() {
    const qs = [...Q].sort(() => Math.random() - .5).slice(0, 8); let score = 0;
    for (let i = 0; i < qs.length; i++) {
      const [round, q, right, wrong] = qs[i]; mood('ok');
      const picked = await new Promise((res) => {
        const opts = [right, ...wrong].sort(() => Math.random() - .5);
        fill(card, h('div', { style: 'font-size:15px;color:#777' }, `Question ${i + 1} of 8 · ${round}`), h('h2', { style: 'margin-top:6px' }, q),
          h('div', { class: 'answers' }, opts.map((o) => h('button', { onclick: (e) => res([o, e.currentTarget]) }, o))));
      });
      const ok = picked[0] === right; if (ok) score++;
      for (const b of card.querySelectorAll('.answers button')) { b.disabled = true; if (b.textContent === right) b.classList.add('right'); }
      if (!ok) picked[1].classList.add('wrong');
      mood(ok ? 'happy' : 'sad'); ok ? sfx.good() : sfx.bad();
      await wait(1300);
      if (!root.isConnected) return;
    }
    const won = score >= 6, first = won && app.award('quiz'); mood(won ? 'happy' : 'sad'); if (won) confetti(root);
    fill(card, h('h2', {}, `${score} out of 8`), h('p', {}, won ? (first ? 'That is a wrap! You won the Creator Studio ring.' : 'Another great show.') : 'Six right wins the ring. Want another take?'),
      h('div', { class: 'row' }, h('button', { class: 'btn', onclick: run }, 'Play again'), h('button', { class: 'btn alt', onclick: exit }, 'Done')));
  }
  intro();
}
